#pragma once
#ifndef ArrayException_h
#define ArrayException_h

#include <string>

//Objective -> In this file we declare and define the components of our Array Exception class


class ArrayException {

private:

public:
	ArrayException() {}
	virtual ~ArrayException(){}
	virtual std::string GetMessage() const = 0; //Our derived class OutOfBoundsException will overrite this function; It will have it's own meaning for the GetMessage() function hence we can make this a pure virtual function
												//By making a function pure virtual in the base class, this forces us to implement a definition for the GetMessage() function in the derived class since a pure virtual function has no body/definition. We have done this so no problems; If this isin't done then the derived class also becomes an abstract class
												//With abstract classes, we can't make a object of type abstract class
};

#endif