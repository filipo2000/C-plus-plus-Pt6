#ifndef Array_cpp 
#define Array_cpp

#include "Array.h"
#include "OutOfBoundsException.h"

using namespace std;

//value of this -> adress of object that underlying pointer is pointing to in memory; value of *this is the value which the object holds which the underlying point aka this pointer is pointing to

//Since the Array class is a template class, it's name aka we denote it as Array<T> instead of Array

//this.m_data and m_data are the same thing since this is a pointer pointing to the underlying object that initiated the function within the class

//Now given that we have namespaces we need to include the appropriate header file + appropriate namespaces; CAD::Point individually or using Filip::CAD; on top

//(*p + 1) // Mover the pointer 1 place and derefrence this is equivalent to p[1] where *p points to the first element aka 0th index
//(*p) + 1 // Is derefrence the pointer acess the value of the object that the pointer is pointing to and add 1; This is equal to p[0] + 1;
//[] and * derefrencing with pointers specifically do the same thing

//Objective -> Here we define all the contents within the Array class
//We could also do -> include Filip::CAD::Point instead the explicit CAD::Point for each Point instance

//Now that our Array class is a template class it's more flexible. However, if we wish to use Point, Line or Circle objects we still need to include the appropriate header files

namespace Filip {
	namespace Containers {
		template <typename T>
		Array<T>::Array() {
			m_size = 10;
			m_data = new T[m_size];

		}

		template <typename T>
		Array<T>::Array(int sz) {
			m_size = sz;
			m_data = new T[m_size];
		}

		template <typename T>
		Array<T>::Array(const Array<T>& c) {
			m_size = c.m_size;
			m_data = new T[m_size];

			for (int i = 0; i < m_size; i++) {
				m_data[i] = c.m_data[i]; //We can acess the private data member m_data from Array<T> template class object c, since we are working within the Array template class aka defining a function member
			}

		}

		template <typename T>
		Array<T>::~Array() {
			delete[] m_data; //Terminate the array(array doens't exist in memory anymore in heap memory) that pointer m_data pointed to from heap memory -> m_data is now a dangling pointer
		}

		//Size() Function()
		template <typename T>
		int Array<T>::Size() const {
			return m_size;
		}


		//Defining the Get() and Set() Functions
		template <typename T>
		T& Array<T>::GetElement(int index) const {
			if (index >= 0 || index < m_size) { //Index inputted as argument is invalid
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		void Array<T>::SetElement(T* p, const int index) {
			if (index >= 0 || index < m_size) {
				m_data[index] = *p;
			}
			else { 
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		Array<T>& Array<T>::operator=(const Array<T>& c) {
			if (this == &c) {
				return *this;
			}
			else {
				delete[] m_data;
				m_size = c.m_size;
				m_data = new T[m_size]; //Make our pointer m_data point to a new array allocated on the heap
				for (int i = 0; i < m_size; i++) {
					m_data[i] = c.m_data[i];
				}
				return *this;
			}
		}

		template <typename T>
		T& Array<T>::operator[](int index) {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		const T& Array<T>::operator[](int index) const {
			if (index >= 0 || index < m_size) {
				return this->m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}



	}
}



#endif


