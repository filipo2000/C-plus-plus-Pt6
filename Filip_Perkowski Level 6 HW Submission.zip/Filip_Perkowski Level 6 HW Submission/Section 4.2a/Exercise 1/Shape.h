#pragma once
#ifndef Shape_h
#define Shape_h

#include <iostream>
#include <sstream>
#include <string>

//Objective -> In this file we declare all the components within the Shape class

namespace Filip {
	namespace CAD {
		
		class Shape {
		private:
			int m_id;
		public:
			Shape();
			Shape(int a);
			Shape(const Shape& c);
			virtual ~Shape();

			//ToString() Function
			virtual std::string ToString() const;

			//Draw() Function
			virtual void Draw() const = 0; //Draw() is a pure virtual function since Shape() has a pure virtual function, Shape() is a abstract class

			//Print() Function
			void Print() const;

			//= operator function
			Shape& operator=(const Shape& c);

			//Get() Function
			int ID() const;

		};

	}
}



#endif