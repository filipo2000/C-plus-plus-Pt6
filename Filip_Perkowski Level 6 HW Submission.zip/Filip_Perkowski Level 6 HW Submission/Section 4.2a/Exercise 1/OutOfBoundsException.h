#pragma once
#ifndef OutOfBoundsException_h
#define OutOfBoundsException_h

#include <string>
#include <sstream>

#include "ArrayException.h" //This is necessary so that all the contents from the ArrayException header file is acessible here

//Objective -> In this file we declare + define all the components in the OutOfBoundsException class

class OutOfBoundsException: public ArrayException {

private:
	int m_index;

public:
	//Constructors and deconstructor
	OutOfBoundsException(){}
	OutOfBoundsException(int a):m_index(a) {}
	virtual ~OutOfBoundsException(){}

	std::string GetMessage() const {
		std::stringstream a,b;
		a << m_index;
		b << "Our index" << a.str() << "is out of bounds!!";
		return b.str();
 
	}



};

#endif