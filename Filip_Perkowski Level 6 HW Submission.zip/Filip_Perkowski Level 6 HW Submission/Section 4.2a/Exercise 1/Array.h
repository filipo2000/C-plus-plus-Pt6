#pragma once
#ifndef Array_h //These preprocessor directives make sure that we define the Array header file only once
#define Array_h

//Objective -> In this file we declare the contents of the Array class

namespace Filip {
	namespace Containers {
		
		template <typename T> //This makes Array a template class
		class Array {
		
		private:
			T* m_data; //Since Point is wihtin the CAD namespace we need to do CAD:: individuall or using Filip::CAD::Point or using namespace Filip::CAD
			int m_size;
		
		public:
			Array();
			Array(int a);
			Array(const Array<T>& c);
			~Array();

			//Functions() which will work on the underlying Array class object
			int Size() const;
			void SetElement(T* p, int index);
			T& GetElement(int index) const;

			//operator=() function
			Array<T>& operator=(const Array<T>& c);

			//[] operator functions -> const and non-const versions
			T& operator[](int index);
			const T& operator[](int index) const;
		};
	}
}

#ifndef Array_cpp //This makes sure that the Array.cpp source file is included only once
#include "Array.cpp" 
#endif

#endif