
#ifndef Array_cpp
#define Array_cpp

#include "Array.h"
#include "OutOfBoundsException.h"

using namespace std;
using namespace Filip::Containers;
using namespace Filip::CAD;

//Let ptr be a ptr -> delete ptr; Deallocatest from memory the object that pointer ptr points to
//if pointer ptr is of local scope then the pointer itself gets terminated from memory when execution continues after the scope in which the pointer was declared in -> aka that's when the constructor is called if we are dealing with classes -> objects of class type

//Since the Array class is a template class, it's name aka we denote it as Array<T> instead of Array

//this.m_data and m_data are the same thing since this is a pointer pointing to the underlying object that initiated the function within the class

//Now given that we have namespaces we need to include the appropriate header file + appropriate namespaces; CAD::Point individually or using Filip::CAD; on top

//(*p + 1) // Mover the pointer 1 place and derefrence this is equivalent to p[1] where *p points to the first element aka 0th index
//(*p) + 1 // Is derefrence the pointer acess the value of the object that the pointer is pointing to and add 1; This is equal to p[0] + 1;
//[] and * derefrencing with pointers specifically do the same thing

//Objective -> Here we define all the contents within the Array class
//We could also do -> include Filip::CAD::Point instead the explicit CAD::Point for each Point instance

// = new int() -> Here a single int object is allocated/created in heap memory value in the paranthese is the value we would like to assign it to

//Now that our Array class is a template class it's more flexible. However, if we wish to use Point, Line or Circle objects we still need to include the appropriate header files so that we can include them appropriately

namespace Filip {
	namespace Containers {
		
		template <typename T> //This is part of the syntax with template classes -> Wheneever you do not decide the define a member of the template class within the template class then we must write this line
		int Array<T>::default_size = 10; //Initializing our static int variable

		template <typename T>
		Array<T>::Array() {
		m_data = new T[default_size]; //we use the new keyword so a pointer is returned. m_data is a pointer which points to the first element of the array which contains elements of type T
		m_size = default_size;
		
		}

		template <typename T>
		Array<T>::Array(int sz) {
			m_data = new T[sz];
			m_size = sz;
		}

		template <typename T>
		Array<T>::Array(const Array<T>& c) {
			m_size = c.m_size;
			m_data = new T[m_size]; // We are not deleting this because we are creating a Array<T> class variable using the copy constructor; There is no array to delete -> we are in the process of initalizing the m_data member for a Array<T> object through the use of a copy constructor

			for (int i = 0; i < m_size; i++) {
				m_data[i] = c.m_data[i];
			}

		}

		template <typename T>
		Array<T>::~Array() {
			delete[] m_data; //This terminates/deletes the array that pointer m_data pointed to from heap memory; This makes m_data a dangling pointer
		}

		template <typename T>
		int Array<T>::Size() const {
			return m_size;
		}


		//Size() Functions() -> Get() AND Set(); Static functions can't be const
		template <typename T>
		int Array<T>::DefaultSize() {
			return default_size;
		}



		template <typename T>
		void Array<T>::DefaultSize(int a) { //using an int as a parameter any Array class object that isin't cased by an int would not call this function; By putting the parameter as type T any object of type Array template class can freely call this function via the . operator
			default_size = a;
		}


		template <typename T>
		void Array<T>::SetElement(T* p, int index) {
			if (index >= 0 || index < m_size) {
				m_data[index] = (*p);
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		T& Array<T>::GetElement(int index) const {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		Array<T>& Array<T>::operator=(const Array<T>& c) {
			if (this == &c) {
				return *this;
			}
			else {
				delete[] m_data;
				m_size = c.m_size;
				m_data = new T[m_size]; //Make our pointer m_data point to a new array(clean slate -> empty array right now) allocated on the heap
				for (int i = 0; i < m_size; i++) {
					m_data[i] = c.m_data[i];
				}
				return *this;
			}
		}

		template <typename T>
		T& Array<T>::operator[](int index) {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		const T& Array<T>::operator[](int index) const {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}



	}
}


#endif