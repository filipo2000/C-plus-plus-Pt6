#include "Array.h"
#include "OutOfBoundsException.h"

using namespace Filip::Containers;
using namespace Filip::CAD;
//Objective -> In this file we are testing the revised Array class which includes a static variable

//A static member passes it's value to all possible objects of a template class type

//IMPORTANT -> With template classes objects we have different types; A type includes the name of the class + the casing so for example:
//Array<int> is one type, Array<double> is another type , Resi<int> is another type etc.

//T denotes the casing in our template class object
//So if we have a function in our template class like the following: T remi(T a); The point of the T's is to make the function flexible so if we call function remi with a template class object Array<double> arr , then T is a double; The whole point is that we can call the function using an type of template class object -> Array<int>, Array<string> etc.
//And we make the following template class object Array<int> resi; Then to call function remi using object resi we do -> resi.remi(an int variable/value)
//In the case of object resi; Function remi takes a int argument given that it's parameter is an int and it also returns an int value since variable resi is cased with an int

int main() {


	Array<int> intArray1; //Can only provide int arguments hence it can only call functions with int parameters etc. With non templates then passing an int to a double would work as the compiler would truncate. However, with templates its strict
	Array<int> intArray2;
	Array<double> doubleArray;
	cout << intArray1.DefaultSize() << endl; //10
	cout << intArray2.DefaultSize() << endl; //10
	cout << doubleArray.DefaultSize() << endl; //10
	intArray1.DefaultSize(15); //Since our default_value is a static variable -> 15 is the default_value for all the objects of Array template class type that are cased with an int -> aka Array<int> so for the Array<int> class static value is now 15; This will be therefore be the case for all objects of type Array<int>
	cout << intArray1.DefaultSize() << endl; //15
	cout << intArray2.DefaultSize() << endl; //15; We don't need to do intArray2.DefaultSize(15) because the default_size member is static. If it weren't then we would have to do this; 
	cout << doubleArray.DefaultSize() << endl; //Doesn't change to 15 but stays at 10 since intArray1 is of type Array<int> and doubleArray is an object of type Array<double>; 15 is the default value for all possible objects of type Array<int>

	//So if we make the following Array template class object Array<double,int, string> then the when we call a function using this Array template class object and the . operator -> then we should have 3 arguments in the parentheses -> of type double, int and string -> strictly in this order

	//doubleArray.DefaultSize(20); //This is valid if we wanted to change the default_size member for object doubleArray and all objects of type Array<double> as long as the default_size variable is static; An int parameter is present therefore a int arguement is requested 
	//We could freely pass a double argument to an int parameter, truncation would occur; int argument to a double parameter yield an error







}