#pragma once
#ifndef NumericArray_h
#define NumericArray_h

#include "Array.h"
using namespace Filip::Containers;

//Objective -> In this file we define the components of the NumericArray class

//template<typename T> and template<class T> are the same generally speaking there are some instances/idea in templates where the class keyword must be used instead of typename and vice versa
//In C++, we only have class templates -> These are templates that generate classes like Array<int>, Array<double> so these are individually generated classes from class template Array
//So now if we make the following object Array<int> geo; Geo is simply an object of class Array<int> -> In this case geo would call the Array<int> version as T is of type int since format in templates is name<T>

//template parameter within a class template -> This is like using a class template within the class template that we are defining
//now the benefit of using template <class T> or template <typename T> is that when creating a template class -> using template <class T> we can implement parameters whereas with the second we won't be able to implement parameters

// class NumericArray: public Array -> This is not valid since Array is a class template -> therefore it can't serve as a base class in inheritance
//By writing [public Array<T>] -> this is generic inheritance -> we are creating generic inheritance aka Array<int> class, Array<double> class all the classes that class template Array is able to generate are base classes for class template Numeric Array

template <typename T> //This is needed to denote that Numeric Array is a template class
class NumericArray : public Array<T> { 
	
	public:
		//Defining our constructors and deconstructor
		NumericArray(); //Default constructor
		NumericArray(int sz);
		NumericArray(const NumericArray<T>& c); //Copy constructor
		~NumericArray(); //Deconstructor

		//Operator() Functions
		NumericArray<T>& operator=(const NumericArray<T>& c);
		NumericArray<T>& operator*(T scale);
		NumericArray<T>& operator+(const NumericArray<T>& source); //Parameter should be a NumericArray<T> object since we should be providing such a argument
		
		//DotProduct() function
		T DotProduct(const NumericArray<T>& c) const; //We wont be changing the parameters values hence we can label them as const
};

//This directive is necessary when using class templates
#ifndef NumericArray_cpp
#include "NumericArray.cpp"
#endif



#endif