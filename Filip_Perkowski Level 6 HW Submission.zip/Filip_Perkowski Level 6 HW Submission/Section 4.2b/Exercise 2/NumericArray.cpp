#ifndef NumericArray_cpp
#define NumericArray_cpp

#include "Array.h"
#include "NumericArray.h"
#include "SizeException.h"

using namespace Filip::Containers;

//Objective -> In this file we define all the components within our NumericArray template class -> aka template that generates classes

//We defining our functions of a template class -> we should use template<typename T> rather than template <class T> since they are members of a class after all and not a class itself

//Defining our constructors and deconstructor -> By calling the base class constructor in our derived classes constructors
template <typename T>
NumericArray<T>::NumericArray(): Array<T>() {
	

}

template <typename T>
NumericArray<T>::NumericArray(int sz): Array<T>(sz) {
	
}

template <typename T>
NumericArray<T>::NumericArray(const NumericArray<T>& source): Array<T>(source){
	
}

//Our Deconstructor
template <typename T>
NumericArray<T>::~NumericArray() { 

}

//Operator() Functions
template <typename T>
NumericArray<T>& NumericArray<T>::operator=(const NumericArray<T>& c) {
	if (this == &c) {
		return *this;
	}
	else {
		Array<T>::operator=(c); //Assign the contents of the Numeric Array from the base class via the =operator function from the base class
		return *this;
	}
}


template <typename T>
NumericArray<T>& NumericArray<T>::operator*(T scale) {
	for (int i = 0; i < this->Size(); i++) {
		(*this)[i] = (*this)[i] * scale;
	}
return *this;

}

template <typename T>
NumericArray<T>& NumericArray<T>::operator+(const NumericArray<T>& source) {
	if ((*this).Size() != source.Size()) {
		throw SizeException();
	}
	else { //Add elements of both numeric arrays
		for (int i = 0; i < this->Size(); i++) {
			(*this)[i] = (*this)[i] + source[i];
		}
	}
	return *this;
}

template <typename T>
T NumericArray<T>::DotProduct(const NumericArray<T>& c) const { //A dot product can only be an int value it doesn't make sense for a dot product to be of string type hence the int return value of this function
	T sum = 0; //Creating a running sum variable which will hold the dot product
	if ((*this).Size() != c.Size()) {
		throw SizeException(); //We can't find the dot product if the sizes of our Numerical Arrays are not the same -> We throw a size exception
	}
	else {
		for (int i = 0; i < (*this).Size(); i++) {
			sum += c[i] * (*this)[i];
		}
	}
	return sum; 
}

#endif