#pragma once
#ifndef SizeException_h
#define SizeException_h

#include "ArrayException.h"

//Objecitve -> In this file we declare and define the contents of the SizeException class


class SizeException: public ArrayException {

private:



public:
	SizeException(){}
	virtual ~SizeException(){}

	//Since we are inheriting from an abstract class we need to define the SizeException's version of the GetMessage() function
	std::string GetMessage() const {
		std::string resi = "Strings are not of equal length -> Error!";
		return resi;

	}






};


#endif