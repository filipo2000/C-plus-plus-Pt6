#include "Array.h"
#include "ArrayException.h"
#include "OutOfBoundsException.h"
#include "SizeException.h"
#include "NumericArray.h"
#include "Point.h"

using namespace Filip::Containers;
using namespace Filip::CAD;
//this.Area() makes no sense you can't use the . operator on a pointer
//*this.Area() aka this -> Area() is valid -> Derefrence occurs first we get a particular class object's value from there we can use the class object to fetch the Area() member/function of that class

//return *this -> Returns the underlying object that initiated the function/class member aka the object that this pointer is pointing to Ex: underlying object is a then return *this returns a aka the value stored in variable a
//return this -> Returns the value of this aka the adress of the underlying object Ex: underlying object is a then return this -> returns &a the adress of variable a in stack memory aka the value of pointer this


//Objective -> Here we test if everything works as it should

int main() {

	NumericArray<int> obj(5);
	NumericArray<int> obj1(9);
	obj1 = obj; // = operator
	std::cout << obj.Size() << std::endl; //Prints out 5
	std::cout << obj1.Size() << std::endl; //Prints out 5
	obj1 = obj1 * 2; //* operator
	
	for (int i = 0; i < obj1.Size(); i++) {

		std::cout << (obj1)[i] << std::endl;
	}
	

	std::cout << obj.DotProduct(obj1) << std::endl;

	NumericArray<Point> remi; //Yes we can make an object of type NumericArray<Point> since template class is NumericArray<T> 
	//Type used as template argument can be any as the template argument is of type T

}