#include "Array.h"
#include "Stack.h"
#include "StackException.h"

#include <iostream>
#include <string>
#include <sstream>
using namespace Filip::Containers;

//Objective -> In this file we test if everything/all the files work

int main() {

	Stack<int, 3> b_stack; //2 template arguments this time when creating an object of type Stack<T,int>
	Stack<int, 2> c_stack; //Both Stack objects come from the same class Stack<int, int> however we can't copy/assign them to eachother since the 2nd arguments are different

	for (int i = 0; i < 3; i++) { //We can't acess a_stack to then get Size() here since a_stack it a private member of Stack<T,int> and private members can only be acessed within the scope of the class
		std::cout << b_stack.Pop() << std::endl;


	}

}