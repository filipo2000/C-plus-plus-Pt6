
#ifndef StackFullException_h
#define StackFullException_h

#include "StackException.h"
#include <string>
#include <iostream>
#include <sstream>

//Objective -> In this file we declare + define the components of our Stack Full Exception class

class StackFullException : public StackException {
private:
	int m_index;

public:
	StackFullException() {};
	StackFullException(int a) : m_index(a) {};
	~StackFullException() {};

	std::string GetMessage() const {
		std::stringstream a;
		std::string resi = "Out of bounds index: " + a.str() + "is out of range!!";
		return resi;
	}





};



#endif