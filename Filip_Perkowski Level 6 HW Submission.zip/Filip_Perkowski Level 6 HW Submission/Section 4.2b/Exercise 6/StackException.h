
#ifndef StackException_h
#define StackException_h


//Objective -> In this file we declare and define the components in our StackException class

class StackException {
private:


public:
	StackException() {};
	virtual ~StackException() {}; //Destructor is virtual
	virtual std::string GetMessage() const = 0; //Pure virtual function -> Hence this is an abstract class







};


#endif