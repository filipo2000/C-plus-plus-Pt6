#ifndef Stack_cpp
#define Stack_cpp
#include "Stack.h" //By including this file we are also including Array.h indirectly in this(Stack.cpp) file; This is because Stack.h includs Array.h
#include "StackFullException.h"
#include "StackEmptyException.h"

//With inheritance, the derived class takes everything from the base class except for the base classses constructors and deconstructor. Here, the derived class can only call the base class and base class deconstructor within it's own members/ aka within the derived class; So for instance we can call the base class constructor in the derived class constructor

//Objective -> In this file we define the components of the Stack class

//We should be using the colon syntax since it's more efficient

//The catch block of a try catch block is only ran if an exception is thrown in the try block aka there is a throw statement; Otherwise, we run the try block and the try block is skipped

template <typename T>
Stack<T>::Stack() : m_current(0) {
	a_stack = Array<T>(); //Initialize our Array<T> object by calling the default constructor on it
}

template <typename T>
Stack<T>::Stack(int a) : m_current(a) {
	a_stack = Array<T>(a);
}

template <typename T>
Stack<T>::Stack(const Stack<T>& c) : m_current(c.m_current), a_stack(c.a_stack) {

}

template <typename T>
Stack<T>::~Stack() {

}

//Push() function
template <typename T>
void Stack<T>::Push(const T* p) { //No need to check if m_current < a_stack.Size() since the Stack throws an exception whenever the stack becomes full
	try { 
		if (m_current < 0) { //a_stack vs (*this).a_stack -> Both of these are the same thing
				m_current = 0; //Reset index so it points to the first element in the Stack -> Othwerwise if we were in a loop and would like to push elements if the user inputted a large negative number we would be just throwing Stack Exceptions 
			}
			a_stack[m_current] = (*p);
				m_current += 1;
		
		
	}
	catch (...) {
		throw StackFullException(m_current); //Create an StackFull object by initializing the constructor that takes a int argument
	}
	
		
}


template<typename T>
const T& Stack<T>::Pop() {
	try {
		if (m_current < 1 ) {
			m_current = 0;
		}
		
		m_current = m_current - 1;
		return a_stack[m_current];
	
	}
		catch (...) {
		throw StackEmptyException(m_current); //Create an StackEmpty object by initializing the constructor that takes a int argument
		m_current = 0; //Reset the index to 0
	}


}
	


template <typename T>
Stack<T>& Stack<T>::operator=(const Stack<T>& c) {
	if (this == &c) {
		return *this;
	}
	else {
		(*this).a_stack = c.a_stack;
		(*this).m_current = c.m_current;
		return *this;
	}

}



#endif