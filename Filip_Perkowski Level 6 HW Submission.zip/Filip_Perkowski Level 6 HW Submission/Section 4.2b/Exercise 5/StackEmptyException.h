#pragma once
#ifndef StackEmptyException_h
#define StackEmptyException_h

#include "StackException.h" //This header file is needed so that header file is defined here. As a result, we can seamlessly implement the inheritance


//Objective -> In this file we declare + define the components of the StackEmptyException class
//When making a constructor non-virtual when creating a derived class object -> the base class constructor + the derived class constructor is called
//When using the virtual keyword on a destructor on the base class this will ensure that the derived object will get destroyed properly;
//virtual in base class keyword + virtual in derived class keyword for a given class function member -> is the same thing as just putting virtual keyword for the function member in the base class

//There is no such thing as a virtual constructor in C++; By default, the constructor always does the right job

class StackEmptyException : public StackException {

private:
	int m_index;

public:
	StackEmptyException() {};
	StackEmptyException(int a): m_index(a) {};
	~StackEmptyException() {};

	std::string GetMessage() const {
		std::stringstream a,b;
		a << m_index;
		b << "Index" << a.str() << "is not in bounds";
		return b.str();
	}



};



#endif
