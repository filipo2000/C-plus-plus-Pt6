
#pragma once
#ifndef Stack_h
#define Stack_h

#include "Array.h" //We need this file + according namespace inclusion statement to use Array template class in our Stack template class
using namespace Filip::Containers;

//Objective -> In this file we declare the components within the Stack class
//Array template class will be used within the stack template class

//Within class scope everything is acessible for a object of class type. Outside class scope a class object can only acess the public members via the . operator. Using a pointer which points to a class object also works

//In C++ -> We have a concept called composition; This is where we create a object of class type in another class;This way you have a function from Class A; Part of it's body include a call/execution of a function in class B. Since we have a object of class B as a private member in class A

template <class T> //By using this syntax we are denoting that this is a template class
class Stack {
private:
	int m_current; //Int value to hold the current position
	Array<T> a_stack; //Implementing a Array temlpate class data member in our Stack template class

public:
	//Constructors + Destructor
	Stack();
	Stack(int a);
	Stack(const Stack<T>& c);
	~Stack();

	//Pop() function
	const T& Pop();

	//Push() function
	void Push(const T* p);

	//= operator() function
	Stack<T>& operator=(const Stack<T>& c);


};


#ifndef Stack_cpp
#include "Stack.cpp"
#endif

#endif

