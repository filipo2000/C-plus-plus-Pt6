#include "Array.h"
#include "Stack.h"
#include "ArrayException.h"
#include "OutOfBoundsException.h"
#include "StackException.h"
#include "StackEmptyException.h"
#include "StackFullException.h"

#include <iostream>
//Objective -> In this file we test if everything works together

int main() {

	int len;
	std::cout << "Length for the Stack: ";
	std::cin >> len;

	Stack<int> p_stack;

	try {
		for (int i = 0; i < len; i++) {
			std::cout << p_stack.Pop() << std::endl;
		}


	}
	
	catch (StackException& o) {
		std::cout << o.GetMessage();
	}












}