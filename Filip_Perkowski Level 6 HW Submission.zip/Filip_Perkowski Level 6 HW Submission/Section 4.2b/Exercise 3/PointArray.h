#pragma once

#ifndef PointArray_h
#define PointArray_h

//Objective -> Here we define all the components within the Point Array class

#include "Array.h" //This is needed so this file has acess to the Array header file
#include "Point.h"
using namespace Filip::Containers; //This is needed see we have visibility/can acess the Array class since it's within a namespace within the header file
using namespace Filip::CAD; //This namespace inclusion + #include "Point.h" let's us use the Point class freely in this .h file


class PointArray : public Array<Point> {  //By making it Array<int> we make this concrete inheritance
	private:


	public:
		//Our constructors and deconstructor
		PointArray();
		PointArray(int a);
		PointArray(const PointArray& c);
		~PointArray();

		//operator() functions
		PointArray& operator=(const PointArray& c);
		
		//Length() Function
		int Length() const;



};

//Point Array is not a template class so we don't need to include .cpp file here

#endif