#pragma once
#ifndef OutOfBoundsException_h
#define OutOfBoundsException_h

#include "Array.h"
#include "ArrayException.h" //This header file inclusion is needed for proper inheritance to occur
#include <iostream>
#include <sstream>
#include <string>

//Objective -> In this file we declare all the components within the OutOfBoundsException class

class OutOfBoundsException : public ArrayException {
private:
	int m_index;
public:
	//Constructor and Deconstructor
	OutOfBoundsException() {}
	OutOfBoundsException(int a) :m_index(a) {} //Constructor that takes in an int as an argument
	virtual ~OutOfBoundsException() {} //Virtual deconstructor so that a only the derived classes constructor gets called whenever a derived class object gets terminated/deleted from memory -> usually when the program ends; If we don't put this virtual keyword then the derived classes deconstructor will execute as well as the base class -> the whole chain if a derived class iherits from a class that happens to be a derived class etc. All the deconstructors would get initiated

	//Get Message() Function
	std::string GetMessage() const {
		std::stringstream a;
		a << m_index;
		std::string resi = "Index:" + a.str() + "is not in range - Error";
		return resi;

	}





};

#endif
