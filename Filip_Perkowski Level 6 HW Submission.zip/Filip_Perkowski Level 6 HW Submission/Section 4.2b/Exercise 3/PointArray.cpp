
#include "PointArray.h"
//No need to write include namespace Filip::Containers here since we include the PointArray file here and that file includes the namespace; So the namespace is included in this file indirectly

//Objective -> In this file we define all the components within the Point Array Class

//this. does'nt work since it doesn't make sense to use the . operator acess a member of a pointer -> it's value
//*this. aka this -> works; Derefrencing happens first to get the value of the object that the pointer is pointing to. From there we can acess a member from the object's type class

//Defining our constructors + deconstructor

PointArray::PointArray(): Array<Point>() {
	//Calling the base class constructor within the derived class constructor -> Remember that a given derived class object contains all the base class members + more(whatever members are in the body of the derived class) -> Calling the base class constructor gives values for members of a derived class object that come from the base class
}


PointArray::PointArray(int a): Array<Point>(a) {
	
}


PointArray::PointArray(const PointArray& c): Array<Point>(c) {
	
}


PointArray::~PointArray() {
	
}

//=operator() function
PointArray& PointArray::operator=(const PointArray& c) {
	if (this == &c) {
		return *this;
	}
	else {
		Array<Point>::operator=(c);
		return *this;
	}
}

//Length() Function

int PointArray::Length() const {
	int len = 0;
	if ((*this).Size() < 2) { //Need at least 2 points to capture the length
		std::cout << "Point array object doesn't have enough members!!" << std::endl;
	}

	else {
		for (int i = 0; i < (*this).Size(); i++) {
			len = len + ((*this)[i]).Distance((*this)[i + 1]); //Applying the Distace() function between the current and the following points and using a running sum
		}
	}
	
	return len;
}

