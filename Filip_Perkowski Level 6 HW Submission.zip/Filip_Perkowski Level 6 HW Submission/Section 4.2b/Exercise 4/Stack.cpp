#ifndef Stack_cpp
#define Stack_cpp
#include "Stack.h" //By including this file we are also including Array.h indirectly in this(Stack.cpp) file; This is because Stack.h includs Array.h

//With inheritance, the derived class takes everything from the base class except for the base classses constructors and deconstructor. Here, the derived class can only call the base class and base class deconstructor within it's own members/ aka within the derived class; So for instance we can call the base class constructor in the derived class constructor

//Objective -> In this file we define the components of the Stack class

//We should be using the colon syntax since it's more efficient

template <typename T>
Stack<T>::Stack(): m_current(0) {
	a_stack = Array<T>(); //Initialize our Array<T> object by calling the default constructor on it
}

template <typename T>
Stack<T>::Stack(int a): m_current(a) {
	a_stack = Array<T>(a);
}

template <typename T>
Stack<T>::Stack(const Stack<T>& c): m_current(c.m_current), a_stack(c.a_stack) {
	 
}

template <typename T>
Stack<T>::~Stack() {

}

//Push() function
template <typename T>
void Stack<T>::Push(const T* p) { //Running a function from the Array<T> template class in one of our Stack<T> member functions through the use of a_stack -> This is called delegation
	if (m_current < 0) { //If index is not valid; a_stack vs (*this).a_stack -> Both of these are the same thing
		m_current = 0; //Reset the index to 0
	}
		if (m_current < a_stack.Size()) {
				a_stack[m_current] = (*p);
				m_current += 1; //Adjustment is done within this scope if stack is full then we won't enter these if statements 
			}
}
	
	

template<typename T>
const T& Stack<T>::Pop() {
	if (m_current < 0) { //If index is not valid; a_stack vs (*this).a_stack -> Both of these are the same thing
		m_current = 0; //Reset the index
	}
	if (m_current <= a_stack.Size()) { //Decrementation happens first then acess via []. therefore the index can be at most the size of the stack; Since it will be decremented first this will yield the last index(aka length of stack -1) and then we will acess it via []
		m_current = m_current - 1;
		return a_stack[m_current];
	}
}


template <typename T>
Stack<T>& Stack<T>::operator=(const Stack<T>& c) {
	if (this == &c) {
		return *this;
	}
	else {
		(*this).a_stack = c.a_stack;
		(*this).m_current = c.m_current;
		return *this;
	}
	
}



#endif







