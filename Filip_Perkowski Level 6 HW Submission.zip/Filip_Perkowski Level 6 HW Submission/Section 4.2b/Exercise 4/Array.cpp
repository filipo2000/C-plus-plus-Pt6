
#ifndef Array_cpp
#define Array_cpp

#include "Array.h"
#include "OutOfBoundsException.h"

//Objective -> In this file we define the components of our Array class


namespace Filip {
	namespace Containers {

		template <typename T> //This is part of the syntax with template classes -> Wheneever you do not decide the define a member of the template class within the template class then we must write this line
		int Array<T>::default_size = 10; //Initializing our static int variable

		template <typename T>
		Array<T>::Array() {
			m_data = new T[default_size]; //we use the new keyword so a pointer is returned. m_data is a pointer which points to the first element of the array which contains elements of type T
			m_size = default_size;

		}

		template <typename T>
		Array<T>::Array(int sz) {
			m_data = new T[sz];
			m_size = sz;
		}

		template <typename T>
		Array<T>::Array(const Array<T>& c) {
			m_size = c.m_size;
			m_data = new T[m_size]; // We are not deleting this because we are creating a Array<T> class variable using the copy constructor; There is no array to delete -> we are in the process of initalizing the m_data member for a Array<T> object through the use of a copy constructor

			for (int i = 0; i < m_size; i++) {
				m_data[i] = c.m_data[i];
			}

		}

		template <typename T>
		Array<T>::~Array() {
			delete[] m_data; //This terminates/deletes the array that pointer m_data pointed to from heap memory; This makes m_data a dangling pointer
		}

		template <typename T>
		int Array<T>::Size() const {
			return m_size;
		}


		//Size() Functions() -> Get() AND Set(); Static functions can't be const
		template <typename T>
		int Array<T>::DefaultSize() {
			return default_size;
		}



		template <typename T>
		void Array<T>::DefaultSize(int a) { //using an int as a parameter any Array class object that isin't cased by an int would not call this function; By putting the parameter as type T any object of type Array template class can freely call this function via the . operator
			default_size = a;
		}


		template <typename T>
		void Array<T>::SetElement(T* p, int index) {
			if (index >= 0 || index < m_size) {
				m_data[index] = (*p);
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		T& Array<T>::GetElement(int index) const {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		Array<T>& Array<T>::operator=(const Array<T>& c) {
			if (this == &c) {
				return *this;
			}
			else {
				delete[] m_data;
				m_size = c.m_size;
				m_data = new T[m_size]; //Make our pointer m_data point to a new array(clean slate -> empty array right now) allocated on the heap
				for (int i = 0; i < m_size; i++) {
					m_data[i] = c.m_data[i];
				}
				return *this;
			}
			
		}

		template <typename T>
		T& Array<T>::operator[](int index) {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}

		template <typename T>
		const T& Array<T>::operator[](int index) const {
			if (index >= 0 || index < m_size) {
				return m_data[index];
			}
			else {
				throw OutOfBoundsException(index);
			}
		}



	}
}


#endif